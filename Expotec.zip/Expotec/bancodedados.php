<?php

$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "ecobusca";
$conexao = mysqli_connect($servidor, $usuario, $senha, $banco);

?>